﻿This directory or its subdirectories should contain OpenVPN
configuration files each having an extension of .ovpn.

When OpenVPN GUI is started, configuration files in this
directory and its subdirectories are added to the list of available
connections.
